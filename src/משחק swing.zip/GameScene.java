import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class GameScene extends JPanel implements KeyListener {
    private Player player;
    private boolean[] pressedKeys;
    private Obstacle[] obstacles;
    public static final int DOWN = 0;
    public static final int UP = 1;
    public static final int LEFT = 2;
    public static final int RIGHT = 3;
    public static final int GAME_SPEED_FAST = 3;
    public static final int GAME_SPEED_NORMAL = 10;
    public static final int GAME_SPEED_SLOW = 25;
    public static final int TOTAL_OBSTACLES = 5;
    private int page;
    public static final int HOME_PAGE = 1;
    public static final int GAME_PAGE = 2;

    public static final int Button_HEIGHT = 30;
    public static final int Button_WIDTH = 200;
    public static final int Button_X = 700;
    public static final int Button_Y = 100;


    public Player getPlayer() {
        return this.player;
    }


    public GameScene() {
        this.page = HOME_PAGE;
        this.setBackground(Color.BLUE);
        this.player = new Player(50, 200);
        this.pressedKeys = new boolean[4];
        this.obstacles = new Obstacle[TOTAL_OBSTACLES];
        for (int i = 0; i < this.obstacles.length; i++) {
            Obstacle obstacle = new Obstacle(this.player.getX() + (i + 1) * 150, Window.WINDOW_HEIGHT / 2);
            this.obstacles[i] = obstacle;
            obstacle.start();
        }

        this.mainGameLoop();
        this.setFocusable(true);
        this.requestFocus();
        this.addKeyListener(this);
    }

    public void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        //int count = 0;
        if (this.page == HOME_PAGE) {
            JButton button1 = new JButton("הוראות המשחק");
            button1.setBounds(Button_X, Button_Y, Button_WIDTH, Button_HEIGHT);
            this.add(button1);
            JButton button2 = new JButton("התחל משחק");
            button2.setBounds(Button_X - 600, Button_Y, Button_WIDTH, Button_HEIGHT);
            this.add(button2);
            JLabel title = new JLabel("");
            title.setBounds(Button_X, Button_Y + 50, Button_WIDTH, Button_HEIGHT);
            this.add(title);

            button1.addActionListener(e -> {
                title.setText("יש להזיז את ארבעת המקשים");
            });
            button2.addActionListener(e -> {
                this.page = GAME_PAGE;
            });

        } else if (this.page == GAME_PAGE&&player.life > 0) {
            this.player.paint(graphics);
            for (int i = 0; i < this.obstacles.length; i++) {
                this.obstacles[i].paint(graphics);
            }
        }

         else if (player.life == 0) {
            JLabel titel = new JLabel();
            titel.setText("Game Over");
            titel.setBounds(Button_X, 400, Button_WIDTH, Button_HEIGHT);
            this.add(titel);
             this.setBackground(Color.white);
            // player.life = player.life3;
        }
    }


    private void mainGameLoop() {
        JLabel titel = new JLabel();
        titel.setText(" " + this.player.life);
        titel.setBounds(Button_X, Button_Y + 50, Button_WIDTH, Button_HEIGHT);
        this.add(titel);
        new Thread(() -> {
            int waitBeforeRevive = 0;
            while (true) {
                int dx = 0;
                int dy = 0;
                if (this.pressedKeys[DOWN] && this.player.getY() + (this.player.SIZE * 3 - 10) <= Window.WINDOW_HEIGHT) {
                    dy++;
                }
                if (this.pressedKeys[UP] && this.player.getY() >= 0) {
                    dy--;
                }
                if (this.pressedKeys[RIGHT]) {
                    dx++;
                }
                if (this.pressedKeys[LEFT] && this.player.getX() > 0) {
                    dx--;
                }
                this.player.move(dx, dy);
                Rectangle playerRect = this.player.calculateRectangle();
                for (int i = 0; i < this.obstacles.length; i++) {
                    Rectangle obstacleRect = this.obstacles[i].calculateRectangle();
                    if (Utils.checkCollision(playerRect, obstacleRect)) {
                        this.player.kill();
                    }
                }
                if (!this.player.isAlive()) {
                    waitBeforeRevive++;
                    if (waitBeforeRevive > 300) {
                        this.player.ChangeLife();
                        titel.setText(" " + this.player.life);
                        this.player.revive();
                        waitBeforeRevive = 0;
                    }
                }
                this.player.overStepsTheBounds();
                repaint();
                Utils.sleep(GAME_SPEED_FAST);
            }
        }).start();
    }

    public void keyTyped(KeyEvent e) {

    }

    public void keyPressed(KeyEvent e) {
        Integer toPress = null;
        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            toPress = RIGHT;
        } else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            toPress = LEFT;
        } else if (e.getKeyCode() == KeyEvent.VK_UP) {
            toPress = UP;
        } else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
            toPress = DOWN;
        }
        if (toPress != null) {
            this.pressedKeys[toPress] = true;
        }

    }

    public void keyReleased(KeyEvent e) {
        Integer toRelease = null;
        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            toRelease = RIGHT;
        } else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            toRelease = LEFT;
        } else if (e.getKeyCode() == KeyEvent.VK_UP) {
            toRelease = UP;
        } else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
            toRelease = DOWN;
        }
        if (toRelease != null) {
            this.pressedKeys[toRelease] = false;
        }

    }
}
