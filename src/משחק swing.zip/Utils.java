import java.awt.*;

public class Utils {
    public static void sleep(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public static boolean checkCollision(Rectangle rect1, Rectangle rect2) {
        boolean collision = false;
        if (rect1.intersects(rect2)) {
            collision = true;
        }
        return collision;
    }
}
    /*
      if (this.page == HOME_PAGE) {
            JButton button1 = new JButton("הוראות המשחק");
            button1.setBounds(Button_X, Button_Y, Button_WIDTH, Button_HEIGHT);
            this.add(button1);
            JButton button2 = new JButton("התחל משחק");
            button2.setBounds(Button_X - 600, Button_Y, Button_WIDTH, Button_HEIGHT);
            this.add(button2);
            JLabel title = new JLabel("");
            title.setBounds(Button_X, Button_Y + 50, Button_WIDTH, Button_HEIGHT);
            this.add(title);

            button1.addActionListener(e -> {
                title.setText("יש להזיז את ארבעת המקשים");
            });
            button2.addActionListener(e -> {
                this.page = GAME_PAGE;
            });

        } else if (this.page == GAME_PAGE)
     */


