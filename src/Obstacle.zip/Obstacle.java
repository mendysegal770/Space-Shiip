import java.awt.*;
import java.util.Random;

public class Obstacle extends Thread {
    private int x;
    private int y;
    public static final int SIZE = 30;
    public static boolean boolSpeed = false;

    public Obstacle(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public boolean getBoolSpeed() {
        return this.boolSpeed;
    }

    public void run() {
        int speed1 = 10;
        int speed2 = 80;
        int s1 = 10;
        int s2 = 5;
        Random random = new Random();
        boolean goingUp = random.nextBoolean();
        int speed = random.nextInt(speed1, speed2);
        int r=random.nextInt(1,3);
        while (true) {
            if (!goingUp&&r==1) {
                this.x++;
                this.y++;
            } else if (goingUp&&r==1){
                this.x--;
                this.y--;
            }
            if (!goingUp&&r==2) {
                this.y++;
            } else if (goingUp&&r==2){
                this.y--;
            }

            if (this.x + SIZE + SIZE > Window.WINDOW_WIDTH||this.y + SIZE + SIZE > Window.WINDOW_HEIGHT) {
                goingUp = true;
            }
            if (this.x < 0||this.y<0) {
                goingUp = false;
            }
            if (boolSpeed && speed > 20) {
                speed = speed - 20;
                boolSpeed = false;
            } else if (boolSpeed && speed < 10 && speed > 5) {
                speed=speed-s2;
                boolSpeed = false;
            }
            Utils.sleep(speed);

        }
    }

    public void paint(Graphics graphics) {
        graphics.setColor(Color.white);
        graphics.fillOval(this.x, this.y, SIZE, SIZE);
    }

    public Rectangle calculateRectangle() {
        return new Rectangle(this.x, this.y, SIZE, SIZE);
    }

}

